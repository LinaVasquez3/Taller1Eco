package vasquezlina;
import processing.core.PApplet;

public class Main extends PApplet {
	
	private Logica logi;

	public static void main(String[] args) {
		PApplet.main("vasquezlina.Main");

	}
	
	public void settings() {
		size(1200,700);
	}
	
	public void setup() {
		logi = new Logica(this);
	}
	
	public void draw() {
		background(255,255,255);
		logi.pintar();
	}
	
	

}
